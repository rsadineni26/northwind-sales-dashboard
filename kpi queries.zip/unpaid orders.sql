SELECT 
    o.id AS order_id,
    i.amount_due
FROM orders o
JOIN invoices i ON o.id = i.order_id

ORDER BY i.amount_due DESC;
