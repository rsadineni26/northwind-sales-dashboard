SELECT 
    o.id AS order_id,
    ROUND(SUM(od.unit_price * od.quantity), 2) AS revenue,
    o.shipping_fee
FROM orders o
JOIN order_details od ON o.id = od.order_id
GROUP BY o.id
ORDER BY revenue DESC
LIMIT 10;
