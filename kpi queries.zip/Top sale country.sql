SELECT 
    o.ship_country_region,
    ROUND(SUM(od.quantity * od.unit_price), 2) AS revenue
FROM orders o
JOIN order_details od ON o.id = od.order_id
GROUP BY o.ship_country_region
ORDER BY revenue DESC;
