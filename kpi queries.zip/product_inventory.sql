SELECT 
    p.product_name,
    SUM(CASE WHEN it.transaction_type = 1 THEN it.quantity ELSE 0 END) AS stocked,
    SUM(CASE WHEN it.transaction_type = 2 THEN it.quantity ELSE 0 END) AS sold,
    SUM(CASE WHEN it.transaction_type = 1 THEN it.quantity ELSE 0 END)
      - SUM(CASE WHEN it.transaction_type = 2 THEN it.quantity ELSE 0 END) AS net_inventory
FROM inventory_transactions it
JOIN products p ON it.product_id = p.id
GROUP BY p.product_name
ORDER BY net_inventory;
