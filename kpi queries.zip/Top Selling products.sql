SELECT 
    p.product_name,
    SUM(od.quantity * od.unit_price) AS total_sales
FROM order_details od
JOIN products p ON od.product_id = p.id
GROUP BY p.product_name
ORDER BY total_sales DESC
LIMIT 10;
