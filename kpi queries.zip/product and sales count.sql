SELECT 
    p.category,
    ROUND(SUM(od.unit_price * od.quantity), 2) AS category_sales
FROM order_details od
JOIN products p ON od.product_id = p.id
GROUP BY p.category
ORDER BY category_sales DESC;
