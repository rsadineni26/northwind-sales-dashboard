SELECT 
    ROUND(SUM(od.unit_price * od.quantity) / COUNT(DISTINCT o.id), 2) AS average_order_value
FROM orders o
JOIN order_details od ON o.id = od.order_id;
