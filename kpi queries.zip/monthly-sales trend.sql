SELECT 
    DATE_FORMAT(o.order_date, '%Y-%m') AS month,
    ROUND(SUM(od.quantity * od.unit_price), 2) AS monthly_revenue
FROM orders o
JOIN order_details od ON o.id = od.order_id
GROUP BY month
ORDER BY month;
