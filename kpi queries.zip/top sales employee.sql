SELECT 
    e.first_name, e.last_name,
    ROUND(SUM(od.unit_price * od.quantity), 2) AS sales
FROM employees e
JOIN orders o ON e.id = o.employee_id
JOIN order_details od ON o.id = od.order_id
GROUP BY e.id
ORDER BY sales DESC
LIMIT 5;
