SELECT 
    p.product_name,
    SUM(CASE WHEN it.transaction_type = 2 THEN it.quantity ELSE 0 END) AS total_sold,
    SUM(CASE WHEN it.transaction_type = 1 THEN it.quantity ELSE 0 END) AS total_stocked
FROM inventory_transactions it
JOIN products p ON it.product_id = p.id
GROUP BY p.product_name
ORDER BY total_sold DESC;
