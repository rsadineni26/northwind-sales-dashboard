SELECT 
    payment_type,
    ROUND(SUM(od.quantity * od.unit_price), 2) AS total_sales
FROM orders o
JOIN order_details od ON o.id = od.order_id
GROUP BY payment_type
ORDER BY total_sales DESC;
