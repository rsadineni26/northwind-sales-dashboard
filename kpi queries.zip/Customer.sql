SELECT 
    c.company AS customer,
    ROUND(SUM(od.unit_price * od.quantity), 2) AS lifetime_value
FROM customers c
JOIN orders o ON c.id = o.customer_id
JOIN order_details od ON o.id = od.order_id
GROUP BY c.id
ORDER BY lifetime_value DESC
LIMIT 10;
