SELECT 
    p.product_name,
    COUNT(od.id) AS times_ordered
FROM order_details od
JOIN products p ON od.product_id = p.id
GROUP BY p.product_name
ORDER BY times_ordered DESC
LIMIT 10;
