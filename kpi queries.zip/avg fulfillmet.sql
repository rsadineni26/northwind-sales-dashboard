SELECT 
    ROUND(AVG(DATEDIFF(shipped_date, order_date)), 2) AS avg_fulfillment_days
FROM orders
WHERE shipped_date IS NOT NULL AND order_date IS NOT NULL;
