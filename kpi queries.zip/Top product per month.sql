SELECT
    sub.month,
    sub.product_name,
    sub.total_sales
FROM (
    SELECT
        DATE_FORMAT(o.order_date, '%Y-%m') AS month,
        p.product_name,
        SUM(od.quantity * od.unit_price) AS total_sales
    FROM orders o
    JOIN order_details od ON o.id = od.order_id
    JOIN products p ON od.product_id = p.id
    GROUP BY month, p.product_name
) sub
WHERE NOT EXISTS (
    SELECT 1
    FROM (
        SELECT
            DATE_FORMAT(o.order_date, '%Y-%m') AS month,
            p.product_name,
            SUM(od.quantity * od.unit_price) AS total_sales
        FROM orders o
        JOIN order_details od ON o.id = od.order_id
        JOIN products p ON od.product_id = p.id
        GROUP BY month, p.product_name
    ) sub2
    WHERE sub2.month = sub.month
      AND sub2.total_sales > sub.total_sales
);


